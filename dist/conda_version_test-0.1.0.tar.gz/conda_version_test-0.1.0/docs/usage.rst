=====
Usage
=====

To use conda_version_test in a project::

    import conda_version_test
