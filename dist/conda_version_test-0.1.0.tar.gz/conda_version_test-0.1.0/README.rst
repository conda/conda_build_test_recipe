===============================
conda_version_test
===============================


.. image:: https://img.shields.io/pypi/v/conda_version_test.svg
        :target: https://pypi.python.org/pypi/conda_version_test

.. image:: https://img.shields.io/travis/conda/conda_version_test.svg
        :target: https://travis-ci.org/conda/conda_version_test

.. image:: https://readthedocs.org/projects/conda-version-test/badge/?version=latest
        :target: https://conda-version-test.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status

.. image:: https://pyup.io/repos/github/conda/conda_version_test/shield.svg
     :target: https://pyup.io/repos/github/conda/conda_version_test/
     :alt: Updates


Conda version sorting test


* Free software: BSD license
* Documentation: https://conda-version-test.readthedocs.io.


Features
--------

* TODO

Credits
---------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage

