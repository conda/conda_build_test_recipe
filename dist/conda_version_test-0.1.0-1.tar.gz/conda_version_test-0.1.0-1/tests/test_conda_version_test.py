#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
test_conda_version_test
----------------------------------

Tests for `conda_version_test` module.
"""


import sys
import unittest

from conda_version_test import conda_version_test



class TestConda_version_test(unittest.TestCase):

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_000_something(self):
        pass



if __name__ == '__main__':
    sys.exit(unittest.main())
